﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestCases
{
    [TestClass]
    public class UnitTest
    {
        [TestMethod]
        //Check if battleship dimensions are less than board dimensions - Negative test case, must fail
        public void testCase_CheckBattleshipDimension_Invalid()
        {
            bool boolResult = true;
            Battleship.Battleship battleship = new Battleship.Battleship();
            battleship.CreateBoard(10, 10);
            battleship.AddBattleShip(11);

            if (battleship.y < battleship.BattleshipSize)
                boolResult = false;

            Assert.AreEqual(true, boolResult, "Invalid dimensions! Battleship's dimensions cannot be greater than board's dimensions.");
        }
        [TestMethod]
        //Check if battleship dimensions are less than board dimensions - Positive test case, must pass
        public void testCase_CheckBattleshipDimension_Valid()
        {
            bool boolResult = true;
            Battleship.Battleship battleship = new Battleship.Battleship();
            battleship.CreateBoard(10, 10);
            battleship.AddBattleShip(8);

            if (battleship.y < battleship.BattleshipSize)
                boolResult = false;

            Assert.AreEqual(true, boolResult, "Invalid dimensions! Battleship's dimensions cannot be greater than board's dimensions.");
        }
    }
}
