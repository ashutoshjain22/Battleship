﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Battleship
{
    class Program
    {
        static void Main(string[] args)
        {
            string val;
            Battleship battleship = new Battleship();
            Console.Write("Enter board dimensions x : ");
            val = Console.ReadLine();
            battleship.x = Convert.ToInt32(val);

            Console.Write("Enter board dimensions y : ");
            val = Console.ReadLine();
            battleship.y = Convert.ToInt32(val);

            battleship.CreateBoard(battleship.x, battleship.y); // Create a board for battleship game.
            Console.WriteLine("Board created with dimensions : " + battleship.x.ToString() +" * " + battleship.y.ToString());

            Console.Write("Enter the size of a battleship: ");
            val = Console.ReadLine();
            battleship.BattleshipSize = Convert.ToInt32(val);

            bool boolCreateBattleship = battleship.AddBattleShip(battleship.BattleshipSize); //Add a Battleship with its size 1 * n

            if (boolCreateBattleship)
                Console.WriteLine("Battleship created!");
            else
            {
                Console.WriteLine("Invaid dimensions! Battleship's dimensions cannot be greater than board's dimensions.");
                Console.ReadKey();
                return;
            }


            int i = 0;
            do
            {
                Console.Write("Enter 1 to attack : ");
                val = Console.ReadLine();
                i = Convert.ToInt32(val);
                //Console.ReadKey();

                if (i != 1)
                    break;

                battleship.Attack();
                Console.WriteLine("Hit counter : " + battleship.HitCounter.ToString() );

                if (battleship.HitCounter == battleship.BattleshipSize)
                    break;

            } while (i == 1 || battleship.HitCounter < battleship.BattleshipSize);

            //Console.ReadKey();

            if (battleship.HitCounter >= battleship.BattleshipSize)
            {
                Console.WriteLine("Hit counter : " + battleship.HitCounter.ToString());
                Console.Write("You win! ");
            }
            else
            {
                Console.WriteLine("Hit counter : " + battleship.HitCounter.ToString());
                Console.Write("you lost!");
            }

            Console.ReadKey();

        }
    }
}
