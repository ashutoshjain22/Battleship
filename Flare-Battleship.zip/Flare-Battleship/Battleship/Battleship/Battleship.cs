﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Battleship
{
    public class Battleship
    {
        public String[,] BattleShipBoard;
        public String[,] BattleShipUserOne;
        public int x, y; //Board dimensions
        public int BattleshipSize; //Battleship size i.e. 1 * n
        public int HitCounter; //No of the boxes of Battleship has been hit successfully. 

        public Battleship()
        {
            HitCounter = 0;
        }
        //When creating the board, we can pass the dimension in constructor i.e. 10*10
        public void CreateBoard(int i, int j)
        {
            x = i;
            y = j;

            BattleShipBoard = new String[x, y];
        }
        public bool AddBattleShip(int n)
        {
            BattleshipSize = n;

            if (n > y)
                return false; //"Invaid dimensions! Battleship's dimensions cannot be greater than board's dimensions.";
            else
            {
                BattleShipUserOne = new String[1, n]; // Create ship with 1 by n size.
                return true; //"Battleship created!";
            }
        }

        public string Attack()
        {
            Random ran = new Random();
            int iResponse = ran.Next(1, 10); //Lets assume, an attack has a random response from 1 to 10
                                             //And assume random divisible by 2 means hit otherwise miss. 
                                             //i.e. 1 = Hit, 0 = Miss

            if (iResponse % 2 == 0)
            {
                HitCounter++;
                return "Hit";
            }
            else
                return "Miss";
        }
    }
}
